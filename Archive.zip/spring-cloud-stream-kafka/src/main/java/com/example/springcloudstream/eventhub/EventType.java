package com.example.springcloudstream.eventhub;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

public enum EventType {
  CREATE("Create"), UPDATE("Update"), DELETE("Delete");

  private String value;

  EventType(String value) {
    this.value = value;
  }

  @JsonCreator
  public static EventType getEventType(String value) {
    for (EventType type : values()) {
      if (type.getValue().equals(value)) {
        return type;
      }
    }
    return null;
  }

  @JsonValue
  public final String getValue() {
    return this.value;
  }
}
