package com.example.springcloudstream.eventhub;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.time.OffsetDateTime;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class IngestionStatusKafkaMessage {
  private String city;
  private String country;
  private String countryCode;
  private String isp;
  private String lat;
  private String lon;
  private String region;
  private String regionName;
  private String status;
  private OffsetDateTime hittime;
  private int zip;
}

/*

{
"city": "",
"country": "United States",
"countryCode": "US",
"isp": "",
"lat": 0.00, "lon": 0.00,
"query": "",
"region": "CA",
"regionName": "California",
"status": "success",
"hittime": "2017-02-08T17:37:55-05:00",
"zip": "38917"
}

 */