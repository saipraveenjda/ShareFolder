package com.example.springcloudstream.eventhub;

//import com.jda.eventhub.interceptor.ConsumerTenancyInterceptor;
import com.jda.security.tenancy.TenantService;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.channel.AbstractMessageChannel;

//@Configuration
public class ChannelConfiguration {
  private final TenantService tenantService;

  public ChannelConfiguration(TenantService tenantService) {
    this.tenantService = tenantService;
  }

  //@Bean
  public BeanPostProcessor channelConfigurer() {
    return new BeanPostProcessor() {

      @Override
      public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
        return bean;
      }

      @Override
      public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
       if ("ingestionstatusconsumer".equals(beanName)) {
          //(AbstractMessageChannel) bean).addInterceptor(new ConsumerTenancyInterceptor(tenantService);
        }
        return bean;
      }

    };
  }
}