package com.example.springcloudstream.eventhub;

import com.jda.security.tenancy.Tenant;
import com.jda.security.tenancy.TenantNotFoundException;
import com.jda.security.tenancy.TenantService;

import org.springframework.stereotype.Component;

@Component
public class DefaultTenantService implements TenantService {
  @Override
  public Tenant getTenantByAlias(String tenantAlias) throws TenantNotFoundException {
    return new Tenant(tenantAlias, tenantAlias, true);
  }

  @Override
  public Tenant getTenantById(String tenantId) throws TenantNotFoundException {
    return new Tenant(tenantId, tenantId, true);
  }
}
