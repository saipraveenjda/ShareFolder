package com.example.springcloudstream.eventhub;

import org.springframework.cloud.stream.annotation.EnableBinding;

@EnableBinding(MessageStreams.class)
public class EventHubStreamsConfiguration {

}
