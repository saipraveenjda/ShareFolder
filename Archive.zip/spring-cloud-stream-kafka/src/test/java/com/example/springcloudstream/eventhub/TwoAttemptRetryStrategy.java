package com.example.springcloudstream.eventhub;

import com.jda.eventhub.error.retry.TotalAttemptsRetryStrategy;

public class TwoAttemptRetryStrategy extends TotalAttemptsRetryStrategy {
  @Override
  protected long getTotalRetryAttempts() {
    return 9;
  }
}