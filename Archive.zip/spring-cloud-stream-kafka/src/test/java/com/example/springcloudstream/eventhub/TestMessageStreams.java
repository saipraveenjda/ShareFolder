package com.example.springcloudstream.eventhub;

import org.springframework.cloud.stream.annotation.Input;
import org.springframework.messaging.SubscribableChannel;

public interface TestMessageStreams {
  String INGESTIONSTATUS = "ingestionstatusconsumer";

  @Input(INGESTIONSTATUS)
  SubscribableChannel ingestionStatusChannel();
}