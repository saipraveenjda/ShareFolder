package com.example.springcloudstream.eventhub;

import static java.util.Arrays.asList;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

import com.jda.security.tenancy.TenancyContext;
import com.jda.security.tenancy.TenancyContextHolder;
import com.jda.security.tenancy.Tenant;

import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.IntStream;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.DEFINED_PORT, properties = {"server.port=8184"})
@ContextConfiguration(classes = SpringCloudStreamEventHubApplication.class)
@ActiveProfiles(SpringCloudStreamEventHubApplication.Profiles.NO_DEPENDENCIES)
@Slf4j
public class SpringCloudStreamEventHubApplicationTests {

  @Autowired
  private IngestionStatusEventPublisher ingestionStatusEventPublisherService;

  @Autowired
  private IngestionStatusEventHandler ingestionStatusEventHandler;

  @Test
  void testIngestionStatusPublisherService() throws InterruptedException {
    TenancyContextHolder.setContext(TenancyContext.newContext(new Tenant("jda-com", "jda-com", true)));

    ingestionStatusEventPublisherService.publish(givenIngestionStatusMessage("" + 1));

    Thread.sleep(40000);

    assertThat(ingestionStatusEventHandler.getEventCount(), is(1));
  }

  @Test
  void testDatabricksSpark() throws InterruptedException {
    TenancyContextHolder.setContext(TenancyContext.newContext(new Tenant("jda-com", "jda-com", true)));

    for (int i = 0; i < 100; i++) {
      //ingestionStatusKafkaEventPublisherService.publish(givenIngestionStatusKafkaMessage());
    }

    Thread.sleep(100000);

    //assertThat(ingestionStatusEventHandler.getEventCount(), is(10));
  }

  private IngestionStatusMessage givenIngestionStatusMessage() {
    return IngestionStatusMessage.builder()
        .correlationId("some-correlation-id")
        .status("done")
        .source("some-source")
        .eventTime(OffsetDateTime.now().toString())
        .build();
  }

  private IngestionStatusKafkaMessage givenIngestionStatusKafkaMessage() {
    List<String> cities = asList("Hyderabad", "Bangalore", "Chennai", "Mumbai", "Delhi", "Vijayawada");
    List<Integer> zipCodes = asList(500032, 560076, 540234, 510023, 501010, 500002);
    int randomNum = new Random().nextInt(6);

    return IngestionStatusKafkaMessage.builder()
        .city(cities.get(randomNum))
        .country("India")
        .countryCode("Ind")
        .status("Success")
        .zip(zipCodes.get(randomNum))
        .hittime(OffsetDateTime.now().minusSeconds(new Random().nextInt(200)))
        .build();
  }

  private IngestionStatusMessage givenIngestionStatusMessage(String id) {
    return IngestionStatusMessage.builder()
        .correlationId(id)
        .status("done")
        .source("some-source")
        .eventTime(OffsetDateTime.now().toString())
        .build();
  }

  @Test
  void testConcurrency() throws InterruptedException {

    ExecutorService executorService = Executors.newFixedThreadPool(20);
    IntStream.range(0, 9999).boxed().forEach(
        (i) -> executorService.submit(new IngestionStatusPublisherRunnable(i, ingestionStatusEventPublisherService)));

    Thread.sleep(40000);

    //assertThat(ingestionStatusEventHandler.getEventCount(), is(10000));
  }

  private class IngestionStatusPublisherRunnable implements Runnable {
    IngestionStatusEventPublisher ingestionStatusEventPublisherService;
    String id;

    public IngestionStatusPublisherRunnable(
        int id,
        IngestionStatusEventPublisher ingestionStatusEventPublisherService) {
      this.id = "" + id;
      this.ingestionStatusEventPublisherService = ingestionStatusEventPublisherService;
    }

    @Override
    public void run() {
      TenancyContextHolder.setContext(TenancyContext.newContext(new Tenant("jda-com", "jda-com", true)));

      log.info("Sending ingestion status event in Thread: status-{}", id);
      try {
        ingestionStatusEventPublisherService.publish(givenIngestionStatusMessage(id));
      } catch (Exception e) {
        log.error("Exception while sending ingestion status event", e);
      }
    }
  }
}
