package com.example.springcloudstream.eventhub;

import com.jda.eventhub.error.retry.RetryStrategy;
import com.jda.eventhub.handler.EventHandler;

import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.support.ErrorMessage;
import org.springframework.stereotype.Component;

import java.util.concurrent.atomic.AtomicInteger;

@Component
@Slf4j
//@Scope(proxyMode = ScopedProxyMode.TARGET_CLASS)
public class IngestionStatusEventHandler extends EventHandler<IngestionStatusMessage> {
  private AtomicInteger eventCount = new AtomicInteger();
  private final MessageStreams messageStreams;

  public IngestionStatusEventHandler(MessageStreams messageStreams) {
    this.messageStreams = messageStreams;
  }

  @StreamListener(TestMessageStreams.INGESTIONSTATUS)
  @Override
  public void handleEvent(Message<IngestionStatusMessage> message) throws Exception {

    if (Integer.valueOf(message.getHeaders().get("deliveryAttempt").toString()) == 1) {
      eventCount.incrementAndGet();
      log.info("Event Count is {} ", eventCount.get());
      log.info("New ingestion status event received: {}", message.getPayload().getCorrelationId());
    }
    //if (eventCount.get() % 5 == 0)
    //throw new Exception();

    // process the event
  }

  @Override
  @ServiceActivator(inputChannel = "ingestion-status.testconsumergroup.errors")
  protected void handleError(ErrorMessage errorMessage) throws Exception {
    processError(errorMessage);
  }

  @Override
  protected MessageChannel getDlqChannel() {
    return null;
  }

  @Override
  protected RetryStrategy retryStrategy() {
    return new TwoAttemptRetryStrategy();
  }

  @Override
  protected MessageChannel getRepublishChannel() {
    return messageStreams.ingestionStatusChannel();
  }

  public int getEventCount() {
    return eventCount.get();
  }
}